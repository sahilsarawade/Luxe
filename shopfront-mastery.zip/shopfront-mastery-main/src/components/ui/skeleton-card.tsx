import React from 'react';
import { cn } from '@/lib/utils';

interface SkeletonCardProps {
  className?: string;
}

export const ProductCardSkeleton: React.FC<SkeletonCardProps> = ({ className }) => {
  return (
    <div className={cn('space-y-4', className)}>
      <div className="aspect-[3/4] rounded-lg skeleton-shimmer" />
      <div className="space-y-2">
        <div className="h-4 w-3/4 rounded skeleton-shimmer" />
        <div className="h-4 w-1/2 rounded skeleton-shimmer" />
      </div>
    </div>
  );
};

export const ProductGridSkeleton: React.FC<{ count?: number }> = ({ count = 8 }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <ProductCardSkeleton key={i} />
      ))}
    </div>
  );
};

export const CategoryCardSkeleton: React.FC = () => {
  return (
    <div className="relative aspect-[4/3] rounded-xl overflow-hidden skeleton-shimmer" />
  );
};

export const OrderCardSkeleton: React.FC = () => {
  return (
    <div className="border rounded-lg p-6 space-y-4">
      <div className="flex justify-between">
        <div className="h-5 w-32 rounded skeleton-shimmer" />
        <div className="h-5 w-24 rounded skeleton-shimmer" />
      </div>
      <div className="flex gap-4">
        <div className="h-20 w-20 rounded skeleton-shimmer" />
        <div className="flex-1 space-y-2">
          <div className="h-4 w-3/4 rounded skeleton-shimmer" />
          <div className="h-4 w-1/2 rounded skeleton-shimmer" />
        </div>
      </div>
    </div>
  );
};

export const DashboardStatSkeleton: React.FC = () => {
  return (
    <div className="border rounded-lg p-6 space-y-2">
      <div className="h-4 w-24 rounded skeleton-shimmer" />
      <div className="h-8 w-32 rounded skeleton-shimmer" />
    </div>
  );
};
