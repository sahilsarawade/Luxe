import React from 'react';
import { Product } from '@/types';
import ProductCard from './ProductCard';
import { ProductGridSkeleton } from '@/components/ui/skeleton-card';
import EmptyState from '@/components/ui/empty-state';

interface ProductGridProps {
  products: Product[];
  isLoading?: boolean;
  emptyMessage?: string;
}

const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  isLoading = false,
  emptyMessage = 'No products found',
}) => {
  if (isLoading) {
    return <ProductGridSkeleton count={8} />;
  }

  if (products.length === 0) {
    return (
      <EmptyState
        icon="search"
        title="No products found"
        description={emptyMessage}
        action={{ label: 'Clear filters', href: '/products' }}
      />
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
};

export default ProductGrid;
