import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { CartItem, Product } from '@/types';
import {
  getCart,
  addToCart as apiAddToCart,
  updateCartItem as apiUpdateCartItem,
  removeFromCart as apiRemoveFromCart,
  clearCart as apiClearCart,
  getCartTotal,
  getCartItemCount,
} from '@/api/cartApi';
import { toast } from '@/hooks/use-toast';

interface CartContextType {
  items: CartItem[];
  itemCount: number;
  total: number;
  isLoading: boolean;
  addToCart: (product: Product, quantity?: number, size?: string, color?: string) => Promise<void>;
  updateQuantity: (productId: string, quantity: number, size?: string, color?: string) => Promise<void>;
  removeFromCart: (productId: string, size?: string, color?: string) => Promise<void>;
  clearCart: () => Promise<void>;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load cart on mount
  useEffect(() => {
    const loadCart = async () => {
      try {
        const cartItems = await getCart();
        setItems(cartItems);
      } catch (error) {
        console.error('Failed to load cart:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadCart();
  }, []);

  const addToCart = useCallback(
    async (product: Product, quantity = 1, size?: string, color?: string) => {
      try {
        const updatedCart = await apiAddToCart(product, quantity, size, color);
        setItems(updatedCart);
        toast({
          title: 'Added to cart',
          description: `${product.name} has been added to your cart`,
        });
      } catch (error) {
        toast({
          title: 'Error',
          description: 'Failed to add item to cart',
          variant: 'destructive',
        });
      }
    },
    []
  );

  const updateQuantity = useCallback(
    async (productId: string, quantity: number, size?: string, color?: string) => {
      try {
        const updatedCart = await apiUpdateCartItem(productId, quantity, size, color);
        setItems(updatedCart);
      } catch (error) {
        toast({
          title: 'Error',
          description: 'Failed to update cart',
          variant: 'destructive',
        });
      }
    },
    []
  );

  const removeFromCart = useCallback(
    async (productId: string, size?: string, color?: string) => {
      try {
        const updatedCart = await apiRemoveFromCart(productId, size, color);
        setItems(updatedCart);
        toast({
          title: 'Removed from cart',
          description: 'Item has been removed from your cart',
        });
      } catch (error) {
        toast({
          title: 'Error',
          description: 'Failed to remove item',
          variant: 'destructive',
        });
      }
    },
    []
  );

  const clearCart = useCallback(async () => {
    try {
      await apiClearCart();
      setItems([]);
    } catch (error) {
      console.error('Failed to clear cart:', error);
    }
  }, []);

  return (
    <CartContext.Provider
      value={{
        items,
        itemCount: getCartItemCount(items),
        total: getCartTotal(items),
        isLoading,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
