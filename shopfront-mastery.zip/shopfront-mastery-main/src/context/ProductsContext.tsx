import React, { createContext, useContext, useState, useCallback } from 'react';
import { Product, ProductFilters, PaginatedResponse } from '@/types';
import { getProducts, getProductById, searchProducts as apiSearchProducts } from '@/api/productApi';

interface ProductsContextType {
  products: Product[];
  currentProduct: Product | null;
  filters: ProductFilters;
  pagination: {
    page: number;
    totalPages: number;
    total: number;
  };
  isLoading: boolean;
  error: string | null;
  fetchProducts: (filters?: ProductFilters, page?: number) => Promise<void>;
  fetchProduct: (id: string) => Promise<void>;
  searchProducts: (query: string) => Promise<Product[]>;
  setFilters: (filters: ProductFilters) => void;
  clearFilters: () => void;
}

const ProductsContext = createContext<ProductsContextType | undefined>(undefined);

export const ProductsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);
  const [filters, setFiltersState] = useState<ProductFilters>({});
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 1,
    total: 0,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchProducts = useCallback(async (newFilters?: ProductFilters, page = 1) => {
    setIsLoading(true);
    setError(null);
    try {
      const appliedFilters = newFilters || filters;
      const response: PaginatedResponse<Product> = await getProducts(appliedFilters, page);
      setProducts(response.data);
      setPagination({
        page: response.page,
        totalPages: response.totalPages,
        total: response.total,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch products';
      setError(message);
    } finally {
      setIsLoading(false);
    }
  }, [filters]);

  const fetchProduct = useCallback(async (id: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const product = await getProductById(id);
      setCurrentProduct(product);
      if (!product) {
        setError('Product not found');
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch product';
      setError(message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const searchProducts = useCallback(async (query: string): Promise<Product[]> => {
    try {
      return await apiSearchProducts(query);
    } catch (err) {
      console.error('Search error:', err);
      return [];
    }
  }, []);

  const setFilters = useCallback((newFilters: ProductFilters) => {
    setFiltersState(newFilters);
  }, []);

  const clearFilters = useCallback(() => {
    setFiltersState({});
  }, []);

  return (
    <ProductsContext.Provider
      value={{
        products,
        currentProduct,
        filters,
        pagination,
        isLoading,
        error,
        fetchProducts,
        fetchProduct,
        searchProducts,
        setFilters,
        clearFilters,
      }}
    >
      {children}
    </ProductsContext.Provider>
  );
};

export const useProducts = (): ProductsContextType => {
  const context = useContext(ProductsContext);
  if (!context) {
    throw new Error('useProducts must be used within a ProductsProvider');
  }
  return context;
};
