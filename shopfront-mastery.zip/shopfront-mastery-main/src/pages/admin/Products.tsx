import React, { useEffect, useState } from 'react';
import { getAdminProducts, deleteProduct } from '@/api';
import { Product } from '@/types';
import { Button } from '@/components/ui/button';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import ConfirmDialog from '@/components/ui/confirm-dialog';

const AdminProducts: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    document.title = 'Products | Admin';
    loadProducts();
  }, []);

  const loadProducts = async () => {
    setIsLoading(true);
    const data = await getAdminProducts();
    setProducts(data);
    setIsLoading(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    await deleteProduct(deleteId);
    setProducts(products.filter(p => p.id !== deleteId));
    setDeleteId(null);
    toast({ title: 'Product deleted' });
  };

  return (
    <div className="fade-in">
      <div className="flex justify-between items-center mb-6">
        <h2 className="font-display text-xl font-medium">All Products</h2>
        <Button><Plus className="h-4 w-4 mr-2" />Add Product</Button>
      </div>
      <div className="bg-card border rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-muted/50 text-sm"><tr><th className="text-left p-4">Product</th><th className="text-left p-4 hidden sm:table-cell">Category</th><th className="text-left p-4">Price</th><th className="text-left p-4 hidden md:table-cell">Stock</th><th className="p-4"></th></tr></thead>
          <tbody>
            {products.map(product => (
              <tr key={product.id} className="border-t">
                <td className="p-4"><div className="flex items-center gap-3"><img src={product.image} alt="" className="w-12 h-12 rounded object-cover"/><span className="font-medium truncate max-w-[150px]">{product.name}</span></div></td>
                <td className="p-4 hidden sm:table-cell capitalize">{product.category}</td>
                <td className="p-4">${product.price}</td>
                <td className="p-4 hidden md:table-cell"><span className={product.inStock ? 'text-green-600' : 'text-red-600'}>{product.inStock ? 'In Stock' : 'Out of Stock'}</span></td>
                <td className="p-4"><div className="flex gap-2"><Button variant="ghost" size="icon"><Pencil className="h-4 w-4"/></Button><Button variant="ghost" size="icon" onClick={() => setDeleteId(product.id)}><Trash2 className="h-4 w-4 text-destructive"/></Button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ConfirmDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)} title="Delete Product" description="Are you sure? This cannot be undone." confirmLabel="Delete" onConfirm={handleDelete} variant="destructive" />
    </div>
  );
};

export default AdminProducts;
