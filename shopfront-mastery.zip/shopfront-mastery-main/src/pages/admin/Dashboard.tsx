import React, { useEffect, useState } from 'react';
import { getDashboardStats } from '@/api';
import { DashboardStats } from '@/types';
import { DollarSign, ShoppingCart, Package, Users, TrendingUp } from 'lucide-react';
import { DashboardStatSkeleton } from '@/components/ui/skeleton-card';

const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    document.title = 'Dashboard | Admin';
    getDashboardStats().then(setStats).finally(() => setIsLoading(false));
  }, []);

  const statCards = stats ? [
    { label: 'Total Revenue', value: `$${stats.totalRevenue.toLocaleString()}`, icon: DollarSign, color: 'text-green-600' },
    { label: 'Total Orders', value: stats.totalOrders.toLocaleString(), icon: ShoppingCart, color: 'text-blue-600' },
    { label: 'Total Products', value: stats.totalProducts.toLocaleString(), icon: Package, color: 'text-purple-600' },
    { label: 'Total Customers', value: stats.totalCustomers.toLocaleString(), icon: Users, color: 'text-orange-600' },
  ] : [];

  if (isLoading) return <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">{Array.from({length:4}).map((_,i)=><DashboardStatSkeleton key={i}/>)}</div>;

  return (
    <div className="fade-in">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((stat, i) => (
          <div key={i} className="bg-card border rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">{stat.label}</span>
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </div>
            <p className="text-2xl font-semibold">{stat.value}</p>
          </div>
        ))}
      </div>
      <div className="bg-card border rounded-xl p-6">
        <h2 className="font-display text-lg font-medium mb-4">Recent Orders</h2>
        <div className="space-y-4">
          {stats?.recentOrders.slice(0,5).map(order => (
            <div key={order.id} className="flex justify-between items-center py-2 border-b last:border-0">
              <div><p className="font-medium">{order.id}</p><p className="text-sm text-muted-foreground">{new Date(order.createdAt).toLocaleDateString()}</p></div>
              <span className="font-semibold">${order.total.toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
