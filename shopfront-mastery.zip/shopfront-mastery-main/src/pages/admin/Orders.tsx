import React, { useEffect, useState } from 'react';
import { getAllOrders, updateOrderStatus } from '@/api';
import { Order } from '@/types';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

const statusColors: Record<string, string> = { pending: 'bg-yellow-100 text-yellow-800', processing: 'bg-blue-100 text-blue-800', shipped: 'bg-purple-100 text-purple-800', delivered: 'bg-green-100 text-green-800', cancelled: 'bg-red-100 text-red-800' };

const AdminOrders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  useEffect(() => { document.title = 'Orders | Admin'; getAllOrders().then(setOrders); }, []);

  const handleStatusChange = async (orderId: string, status: Order['status']) => {
    const updated = await updateOrderStatus(orderId, status);
    setOrders(orders.map(o => o.id === orderId ? updated : o));
  };

  return (
    <div className="fade-in">
      <h2 className="font-display text-xl font-medium mb-6">All Orders</h2>
      <div className="bg-card border rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-muted/50 text-sm"><tr><th className="text-left p-4">Order</th><th className="text-left p-4 hidden sm:table-cell">Date</th><th className="text-left p-4">Total</th><th className="text-left p-4">Status</th></tr></thead>
          <tbody>
            {orders.map(order => (
              <tr key={order.id} className="border-t">
                <td className="p-4 font-medium">{order.id}</td>
                <td className="p-4 hidden sm:table-cell text-muted-foreground">{new Date(order.createdAt).toLocaleDateString()}</td>
                <td className="p-4">${order.total.toFixed(2)}</td>
                <td className="p-4">
                  <Select value={order.status} onValueChange={(v) => handleStatusChange(order.id, v as Order['status'])}>
                    <SelectTrigger className={cn('w-32', statusColors[order.status])}><SelectValue /></SelectTrigger>
                    <SelectContent>{['pending','processing','shipped','delivered','cancelled'].map(s => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}</SelectContent>
                  </Select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminOrders;
