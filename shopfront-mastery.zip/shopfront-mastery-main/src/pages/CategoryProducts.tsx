import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import ProductGrid from '@/components/products/ProductGrid';
import ProductFilters from '@/components/products/ProductFilters';
import Breadcrumb from '@/components/ui/breadcrumb-nav';
import Pagination from '@/components/ui/pagination-nav';
import { getProductsByCategory, getCategories } from '@/api';
import { Product, Category, ProductFilters as Filters, PaginatedResponse } from '@/types';

const CategoryProducts: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const [products, setProducts] = useState<Product[]>([]);
  const [categoryInfo, setCategoryInfo] = useState<Category | null>(null);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [filters, setFilters] = useState<Filters>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      if (!category) return;
      setIsLoading(true);
      try {
        const [response, categories] = await Promise.all([
          getProductsByCategory(category, pagination.page),
          getCategories(),
        ]);
        setProducts(response.data);
        setPagination({
          page: response.page,
          totalPages: response.totalPages,
          total: response.total,
        });
        const cat = categories.find((c) => c.slug === category);
        setCategoryInfo(cat || null);
        if (cat) {
          document.title = `${cat.name} | LUXE`;
        }
      } catch (error) {
        console.error('Failed to load category products:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, [category, pagination.page]);

  const handleFiltersChange = (newFilters: Filters) => {
    setFilters(newFilters);
    // In a real app, this would trigger a new API call
  };

  const handlePageChange = (page: number) => {
    setPagination((prev) => ({ ...prev, page }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fade-in">
      {/* Hero Banner */}
      {categoryInfo && (
        <div className="relative h-48 sm:h-64 overflow-hidden">
          <img
            src={categoryInfo.image}
            alt={categoryInfo.name}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 to-foreground/20" />
          <div className="absolute bottom-0 left-0 right-0 container-custom pb-8">
            <h1 className="font-display text-3xl sm:text-4xl font-medium text-primary-foreground">
              {categoryInfo.name}
            </h1>
            <p className="text-primary-foreground/70 mt-2">
              {categoryInfo.productCount} products available
            </p>
          </div>
        </div>
      )}

      <div className="container-custom py-8">
        <Breadcrumb
          items={[
            { label: 'Products', href: '/products' },
            { label: category || '' },
          ]}
          className="mb-6"
        />

        <ProductFilters
          filters={filters}
          onFiltersChange={handleFiltersChange}
          totalProducts={pagination.total}
        />

        <ProductGrid products={products} isLoading={isLoading} />

        <Pagination
          currentPage={pagination.page}
          totalPages={pagination.totalPages}
          onPageChange={handlePageChange}
          className="mt-12"
        />
      </div>
    </div>
  );
};

export default CategoryProducts;
