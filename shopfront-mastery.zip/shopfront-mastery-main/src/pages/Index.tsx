import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Truck, Shield, RefreshCw, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProductCard from '@/components/products/ProductCard';
import { getFeaturedProducts, getCategories } from '@/api';
import { Product, Category } from '@/types';
import { ProductGridSkeleton, CategoryCardSkeleton } from '@/components/ui/skeleton-card';

const Index: React.FC = () => {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    document.title = 'LUXE - Premium Fashion & Lifestyle';
    
    const loadData = async () => {
      try {
        const [products, cats] = await Promise.all([
          getFeaturedProducts(),
          getCategories(),
        ]);
        setFeaturedProducts(products);
        setCategories(cats);
      } catch (error) {
        console.error('Failed to load homepage data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  return (
    <div className="fade-in">
      {/* Hero Section */}
      <section className="relative gradient-hero text-primary-foreground overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1920&h=1080&fit=crop')] bg-cover bg-center opacity-20" />
        <div className="container-custom relative py-20 sm:py-32 lg:py-40">
          <div className="max-w-2xl">
            <span className="inline-block text-accent font-medium mb-4 tracking-wider text-sm uppercase">
              New Collection 2024
            </span>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-medium mb-6 leading-tight">
              Discover Your Signature Style
            </h1>
            <p className="text-lg sm:text-xl text-primary-foreground/80 mb-8 leading-relaxed">
              Explore our curated collection of premium fashion and lifestyle essentials. 
              Quality craftsmanship meets timeless design.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" variant="secondary" asChild className="btn-shine">
                <Link to="/products">
                  Shop Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
                <Link to="/categories/clothing">
                  View Collections
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="border-b bg-card">
        <div className="container-custom py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {[
              { icon: Truck, label: 'Free Shipping', desc: 'Orders over $100' },
              { icon: Shield, label: 'Secure Payment', desc: '100% Protected' },
              { icon: RefreshCw, label: 'Easy Returns', desc: '30-day Policy' },
              { icon: Star, label: 'Premium Quality', desc: 'Guaranteed' },
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                  <feature.icon className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="font-medium text-sm">{feature.label}</p>
                  <p className="text-xs text-muted-foreground">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 sm:py-20">
        <div className="container-custom">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-medium">Shop by Category</h2>
              <p className="text-muted-foreground mt-1">Browse our curated collections</p>
            </div>
            <Link
              to="/products"
              className="hidden sm:flex items-center gap-1 text-sm font-medium text-accent hover:underline"
            >
              View All <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {Array.from({ length: 4 }).map((_, i) => (
                <CategoryCardSkeleton key={i} />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {categories.map((category) => (
                <Link
                  key={category.id}
                  to={`/categories/${category.slug}`}
                  className="group relative aspect-[4/3] rounded-xl overflow-hidden"
                >
                  <img
                    src={category.image}
                    alt={category.name}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-primary-foreground font-display text-lg sm:text-xl font-medium">
                      {category.name}
                    </h3>
                    <p className="text-primary-foreground/70 text-sm">
                      {category.productCount} products
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 sm:py-20 bg-muted/30">
        <div className="container-custom">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-medium">Featured Products</h2>
              <p className="text-muted-foreground mt-1">Handpicked for you</p>
            </div>
            <Link
              to="/products"
              className="hidden sm:flex items-center gap-1 text-sm font-medium text-accent hover:underline"
            >
              View All <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          {isLoading ? (
            <ProductGridSkeleton count={4} />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
              {featuredProducts.slice(0, 4).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="mt-8 text-center sm:hidden">
            <Button variant="outline" asChild>
              <Link to="/products">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Banner */}
      <section className="py-16 sm:py-20">
        <div className="container-custom">
          <div className="relative rounded-2xl overflow-hidden bg-accent/10">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1920&h=600&fit=crop')] bg-cover bg-center opacity-30" />
            <div className="relative px-8 py-16 sm:px-16 sm:py-24 text-center">
              <h2 className="font-display text-3xl sm:text-4xl font-medium mb-4">
                Spring Collection 2024
              </h2>
              <p className="text-muted-foreground max-w-xl mx-auto mb-8">
                Refresh your wardrobe with our latest arrivals. Sustainable fashion 
                that doesn't compromise on style.
              </p>
              <Button size="lg" asChild>
                <Link to="/products">
                  Explore Collection
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 sm:py-20 bg-muted/30">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="font-display text-2xl sm:text-3xl font-medium">What Our Customers Say</h2>
            <p className="text-muted-foreground mt-1">Trusted by thousands worldwide</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                name: 'Sarah M.',
                rating: 5,
                text: 'Amazing quality and fast shipping. The jacket I ordered exceeded my expectations. Will definitely shop here again!',
                image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
              },
              {
                name: 'James L.',
                rating: 5,
                text: 'Best online shopping experience. Customer service was incredibly helpful when I needed to exchange sizes.',
                image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
              },
              {
                name: 'Emily R.',
                rating: 5,
                text: 'Love the sustainable approach to fashion. Beautiful pieces that are kind to the planet. Highly recommend!',
                image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
              },
            ].map((review, i) => (
              <div key={i} className="bg-card rounded-xl p-6 border">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: review.rating }).map((_, j) => (
                    <Star key={j} className="h-4 w-4 fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4 leading-relaxed">"{review.text}"</p>
                <div className="flex items-center gap-3">
                  <img
                    src={review.image}
                    alt={review.name}
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  <span className="font-medium">{review.name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
