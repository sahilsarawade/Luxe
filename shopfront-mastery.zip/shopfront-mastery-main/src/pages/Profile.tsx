import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { User, Mail, Calendar } from 'lucide-react';

const Profile: React.FC = () => {
  const { user, logout } = useAuth();
  React.useEffect(() => { document.title = 'Profile | LUXE'; }, []);

  return (
    <div className="container-custom py-8 fade-in">
      <h1 className="font-display text-3xl font-medium mb-8">My Profile</h1>
      <div className="max-w-2xl">
        <div className="bg-card border rounded-xl p-6 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="h-16 w-16 rounded-full bg-accent/10 flex items-center justify-center">
              <User className="h-8 w-8 text-accent" />
            </div>
            <div>
              <h2 className="font-display text-xl font-medium">{user?.name}</h2>
              <p className="text-muted-foreground">{user?.role === 'admin' ? 'Administrator' : 'Customer'}</p>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-3"><Mail className="h-5 w-5 text-muted-foreground" /><span>{user?.email}</span></div>
            <div className="flex items-center gap-3"><Calendar className="h-5 w-5 text-muted-foreground" /><span>Member since {new Date(user?.createdAt || '').toLocaleDateString()}</span></div>
          </div>
        </div>
        <Button variant="destructive" onClick={logout}>Sign Out</Button>
      </div>
    </div>
  );
};

export default Profile;
