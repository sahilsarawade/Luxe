import React from 'react';
import { Link } from 'react-router-dom';
import { Minus, Plus, X, ShoppingBag, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/context/CartContext';
import EmptyState from '@/components/ui/empty-state';
import { cn } from '@/lib/utils';

const Cart: React.FC = () => {
  const { items, total, updateQuantity, removeFromCart } = useCart();

  React.useEffect(() => {
    document.title = 'Shopping Cart | LUXE';
  }, []);

  if (items.length === 0) {
    return (
      <div className="container-custom py-16">
        <EmptyState
          icon="cart"
          title="Your cart is empty"
          description="Looks like you haven't added anything to your cart yet. Start shopping to fill it up!"
          action={{ label: 'Start Shopping', href: '/products' }}
        />
      </div>
    );
  }

  const shipping = total >= 100 ? 0 : 9.99;
  const grandTotal = total + shipping;

  return (
    <div className="container-custom py-8 fade-in">
      <h1 className="font-display text-3xl sm:text-4xl font-medium mb-8">Shopping Cart</h1>

      <div className="lg:grid lg:grid-cols-3 lg:gap-12">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4 mb-8 lg:mb-0">
          {items.map((item) => (
            <div
              key={`${item.productId}-${item.selectedSize}-${item.selectedColor}`}
              className="flex gap-4 p-4 border rounded-lg"
            >
              <Link
                to={`/products/${item.productId}`}
                className="w-24 h-32 rounded-md overflow-hidden bg-muted shrink-0"
              >
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="h-full w-full object-cover"
                />
              </Link>

              <div className="flex-1 min-w-0">
                <div className="flex justify-between gap-4">
                  <div>
                    <Link
                      to={`/products/${item.productId}`}
                      className="font-medium hover:text-accent transition-colors line-clamp-1"
                    >
                      {item.product.name}
                    </Link>
                    <p className="text-sm text-muted-foreground capitalize">
                      {item.product.category}
                    </p>
                    {(item.selectedSize || item.selectedColor) && (
                      <p className="text-sm text-muted-foreground mt-1">
                        {item.selectedSize && <span>Size: {item.selectedSize}</span>}
                        {item.selectedSize && item.selectedColor && <span> / </span>}
                        {item.selectedColor && <span>Color: {item.selectedColor}</span>}
                      </p>
                    )}
                  </div>
                  <button
                    onClick={() =>
                      removeFromCart(item.productId, item.selectedSize, item.selectedColor)
                    }
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center border rounded">
                    <button
                      onClick={() =>
                        updateQuantity(
                          item.productId,
                          Math.max(0, item.quantity - 1),
                          item.selectedSize,
                          item.selectedColor
                        )
                      }
                      className="p-2 hover:bg-muted transition-colors"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-10 text-center text-sm font-medium">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() =>
                        updateQuantity(
                          item.productId,
                          item.quantity + 1,
                          item.selectedSize,
                          item.selectedColor
                        )
                      }
                      className="p-2 hover:bg-muted transition-colors"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                  <span className="font-semibold">
                    ${(item.product.price * item.quantity).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-card border rounded-xl p-6 sticky top-24">
            <h2 className="font-display text-xl font-medium mb-6">Order Summary</h2>

            <div className="space-y-3 text-sm mb-6">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>${total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
              </div>
              {shipping > 0 && (
                <p className="text-xs text-muted-foreground">
                  Free shipping on orders over $100
                </p>
              )}
              <div className="border-t pt-3 flex justify-between font-semibold text-base">
                <span>Total</span>
                <span>${grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <Button asChild className="w-full btn-shine" size="lg">
              <Link to="/checkout">
                Proceed to Checkout
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            <div className="mt-4 text-center">
              <Link
                to="/products"
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Continue Shopping
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
