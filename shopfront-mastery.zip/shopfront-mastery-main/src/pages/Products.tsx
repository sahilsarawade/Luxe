import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import ProductGrid from '@/components/products/ProductGrid';
import ProductFilters from '@/components/products/ProductFilters';
import Breadcrumb from '@/components/ui/breadcrumb-nav';
import Pagination from '@/components/ui/pagination-nav';
import { getProducts } from '@/api';
import { Product, ProductFilters as Filters, PaginatedResponse } from '@/types';

const Products: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [isLoading, setIsLoading] = useState(true);

  const filters: Filters = {
    category: searchParams.get('category') || undefined,
    minPrice: searchParams.get('minPrice') ? Number(searchParams.get('minPrice')) : undefined,
    maxPrice: searchParams.get('maxPrice') ? Number(searchParams.get('maxPrice')) : undefined,
    rating: searchParams.get('rating') ? Number(searchParams.get('rating')) : undefined,
    search: searchParams.get('search') || undefined,
    sortBy: (searchParams.get('sortBy') as Filters['sortBy']) || undefined,
  };

  const currentPage = Number(searchParams.get('page')) || 1;

  useEffect(() => {
    document.title = 'All Products | LUXE';
    
    const loadProducts = async () => {
      setIsLoading(true);
      try {
        const response: PaginatedResponse<Product> = await getProducts(filters, currentPage);
        setProducts(response.data);
        setPagination({
          page: response.page,
          totalPages: response.totalPages,
          total: response.total,
        });
      } catch (error) {
        console.error('Failed to load products:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadProducts();
  }, [searchParams]);

  const handleFiltersChange = (newFilters: Filters) => {
    const params = new URLSearchParams();
    if (newFilters.category) params.set('category', newFilters.category);
    if (newFilters.minPrice) params.set('minPrice', newFilters.minPrice.toString());
    if (newFilters.maxPrice) params.set('maxPrice', newFilters.maxPrice.toString());
    if (newFilters.rating) params.set('rating', newFilters.rating.toString());
    if (newFilters.search) params.set('search', newFilters.search);
    if (newFilters.sortBy) params.set('sortBy', newFilters.sortBy);
    setSearchParams(params);
  };

  const handlePageChange = (page: number) => {
    const params = new URLSearchParams(searchParams);
    params.set('page', page.toString());
    setSearchParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="container-custom py-8 fade-in">
      <Breadcrumb items={[{ label: 'All Products' }]} className="mb-6" />

      <div className="mb-8">
        <h1 className="font-display text-3xl sm:text-4xl font-medium">
          {filters.search ? `Results for "${filters.search}"` : 'All Products'}
        </h1>
        <p className="text-muted-foreground mt-2">
          Discover our complete collection of premium products
        </p>
      </div>

      <div className="lg:grid lg:grid-cols-[240px_1fr] lg:gap-8">
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block">
          <div className="sticky top-24 space-y-6">
            <ProductFilters
              filters={filters}
              onFiltersChange={handleFiltersChange}
              totalProducts={pagination.total}
            />
          </div>
        </aside>

        {/* Products Grid */}
        <div>
          <div className="lg:hidden mb-6">
            <ProductFilters
              filters={filters}
              onFiltersChange={handleFiltersChange}
              totalProducts={pagination.total}
            />
          </div>

          <ProductGrid products={products} isLoading={isLoading} />

          <Pagination
            currentPage={pagination.page}
            totalPages={pagination.totalPages}
            onPageChange={handlePageChange}
            className="mt-12"
          />
        </div>
      </div>
    </div>
  );
};

export default Products;
