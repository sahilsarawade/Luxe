import React, { useEffect, useState } from 'react';
import { getUserOrders } from '@/api';
import { Order } from '@/types';
import { Package, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import EmptyState from '@/components/ui/empty-state';
import { OrderCardSkeleton } from '@/components/ui/skeleton-card';
import { cn } from '@/lib/utils';

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  processing: 'bg-blue-100 text-blue-800',
  shipped: 'bg-purple-100 text-purple-800',
  delivered: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
};

const Orders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    document.title = 'Orders | LUXE';
    getUserOrders().then(setOrders).finally(() => setIsLoading(false));
  }, []);

  if (isLoading) return <div className="container-custom py-8 space-y-4">{Array.from({length:3}).map((_,i)=><OrderCardSkeleton key={i}/>)}</div>;
  if (orders.length === 0) return <div className="container-custom py-16"><EmptyState icon="orders" title="No orders yet" description="Start shopping to see your orders here" action={{label:'Shop Now',href:'/products'}}/></div>;

  return (
    <div className="container-custom py-8 fade-in">
      <h1 className="font-display text-3xl font-medium mb-8">Order History</h1>
      <div className="space-y-4">
        {orders.map(order => (
          <div key={order.id} className="border rounded-xl p-6">
            <div className="flex flex-wrap justify-between gap-4 mb-4">
              <div><p className="font-medium">{order.id}</p><p className="text-sm text-muted-foreground">{new Date(order.createdAt).toLocaleDateString()}</p></div>
              <span className={cn('px-3 py-1 rounded-full text-xs font-medium capitalize', statusColors[order.status])}>{order.status}</span>
            </div>
            <div className="flex flex-wrap gap-4 mb-4">
              {order.items.slice(0,3).map(item => (
                <div key={item.productId} className="w-16 h-20 rounded overflow-hidden bg-muted">
                  <img src={item.product?.image} alt="" className="h-full w-full object-cover" />
                </div>
              ))}
              {order.items.length > 3 && <div className="w-16 h-20 rounded bg-muted flex items-center justify-center text-sm">+{order.items.length - 3}</div>}
            </div>
            <div className="flex justify-between items-center"><span className="font-semibold">${order.total.toFixed(2)}</span></div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Orders;
