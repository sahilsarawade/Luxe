// Admin API Layer
// Replace mock implementations with actual API calls when backend is ready

import { Product, DashboardStats } from '@/types';
import { mockProducts, mockDashboardStats } from './mockData';

const ADMIN_PRODUCTS_KEY = 'admin_products';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Initialize products in localStorage if not exists
const initProducts = (): Product[] => {
  const stored = localStorage.getItem(ADMIN_PRODUCTS_KEY);
  if (!stored) {
    localStorage.setItem(ADMIN_PRODUCTS_KEY, JSON.stringify(mockProducts));
    return mockProducts;
  }
  return JSON.parse(stored);
};

const saveProducts = (products: Product[]): void => {
  localStorage.setItem(ADMIN_PRODUCTS_KEY, JSON.stringify(products));
};

/**
 * Get dashboard statistics
 * Backend endpoint: GET /api/admin/dashboard
 */
export const getDashboardStats = async (): Promise<DashboardStats> => {
  await delay(400);
  return mockDashboardStats;
};

/**
 * Get all products (admin)
 * Backend endpoint: GET /api/admin/products
 */
export const getAdminProducts = async (): Promise<Product[]> => {
  await delay(300);
  return initProducts();
};

/**
 * Create product (admin)
 * Backend endpoint: POST /api/admin/products
 */
export const createProduct = async (
  productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>
): Promise<Product> => {
  await delay(400);

  const products = initProducts();
  const newProduct: Product = {
    ...productData,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  products.unshift(newProduct);
  saveProducts(products);

  return newProduct;
};

/**
 * Update product (admin)
 * Backend endpoint: PUT /api/admin/products/:id
 */
export const updateProduct = async (
  id: string,
  updates: Partial<Product>
): Promise<Product> => {
  await delay(400);

  const products = initProducts();
  const index = products.findIndex(p => p.id === id);

  if (index === -1) {
    throw new Error('Product not found');
  }

  products[index] = {
    ...products[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  saveProducts(products);
  return products[index];
};

/**
 * Delete product (admin)
 * Backend endpoint: DELETE /api/admin/products/:id
 */
export const deleteProduct = async (id: string): Promise<void> => {
  await delay(300);

  let products = initProducts();
  products = products.filter(p => p.id !== id);
  saveProducts(products);
};

/**
 * Toggle product featured status (admin)
 * Backend endpoint: PUT /api/admin/products/:id/featured
 */
export const toggleProductFeatured = async (id: string): Promise<Product> => {
  await delay(200);

  const products = initProducts();
  const index = products.findIndex(p => p.id === id);

  if (index === -1) {
    throw new Error('Product not found');
  }

  products[index].featured = !products[index].featured;
  products[index].updatedAt = new Date().toISOString();

  saveProducts(products);
  return products[index];
};

/**
 * Toggle product stock status (admin)
 * Backend endpoint: PUT /api/admin/products/:id/stock
 */
export const toggleProductStock = async (id: string): Promise<Product> => {
  await delay(200);

  const products = initProducts();
  const index = products.findIndex(p => p.id === id);

  if (index === -1) {
    throw new Error('Product not found');
  }

  products[index].inStock = !products[index].inStock;
  products[index].updatedAt = new Date().toISOString();

  saveProducts(products);
  return products[index];
};
