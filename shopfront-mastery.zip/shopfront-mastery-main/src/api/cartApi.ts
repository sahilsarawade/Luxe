// Cart API Layer
// Replace mock implementations with actual API calls when backend is ready

import { CartItem, Product } from '@/types';

const CART_KEY = 'shopping_cart';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Helper to get cart from localStorage
const getStoredCart = (): CartItem[] => {
  const cart = localStorage.getItem(CART_KEY);
  return cart ? JSON.parse(cart) : [];
};

// Helper to save cart to localStorage
const saveCart = (items: CartItem[]): void => {
  localStorage.setItem(CART_KEY, JSON.stringify(items));
};

/**
 * Get cart items
 * Backend endpoint: GET /api/cart
 */
export const getCart = async (): Promise<CartItem[]> => {
  await delay(100);
  return getStoredCart();
};

/**
 * Add item to cart
 * Backend endpoint: POST /api/cart/add
 */
export const addToCart = async (
  product: Product,
  quantity = 1,
  selectedSize?: string,
  selectedColor?: string
): Promise<CartItem[]> => {
  await delay(200);

  const cart = getStoredCart();
  const existingIndex = cart.findIndex(
    item =>
      item.productId === product.id &&
      item.selectedSize === selectedSize &&
      item.selectedColor === selectedColor
  );

  if (existingIndex >= 0) {
    cart[existingIndex].quantity += quantity;
  } else {
    cart.push({
      productId: product.id,
      product,
      quantity,
      selectedSize,
      selectedColor,
    });
  }

  saveCart(cart);
  return cart;
};

/**
 * Update cart item quantity
 * Backend endpoint: PUT /api/cart/update/:id
 */
export const updateCartItem = async (
  productId: string,
  quantity: number,
  selectedSize?: string,
  selectedColor?: string
): Promise<CartItem[]> => {
  await delay(150);

  const cart = getStoredCart();
  const index = cart.findIndex(
    item =>
      item.productId === productId &&
      item.selectedSize === selectedSize &&
      item.selectedColor === selectedColor
  );

  if (index >= 0) {
    if (quantity <= 0) {
      cart.splice(index, 1);
    } else {
      cart[index].quantity = quantity;
    }
  }

  saveCart(cart);
  return cart;
};

/**
 * Remove item from cart
 * Backend endpoint: DELETE /api/cart/remove/:id
 */
export const removeFromCart = async (
  productId: string,
  selectedSize?: string,
  selectedColor?: string
): Promise<CartItem[]> => {
  await delay(150);

  let cart = getStoredCart();
  cart = cart.filter(
    item =>
      !(
        item.productId === productId &&
        item.selectedSize === selectedSize &&
        item.selectedColor === selectedColor
      )
  );

  saveCart(cart);
  return cart;
};

/**
 * Clear entire cart
 * Backend endpoint: DELETE /api/cart/clear
 */
export const clearCart = async (): Promise<void> => {
  await delay(100);
  localStorage.removeItem(CART_KEY);
};

/**
 * Get cart total
 */
export const getCartTotal = (items: CartItem[]): number => {
  return items.reduce((total, item) => total + item.product.price * item.quantity, 0);
};

/**
 * Get cart item count
 */
export const getCartItemCount = (items: CartItem[]): number => {
  return items.reduce((count, item) => count + item.quantity, 0);
};
