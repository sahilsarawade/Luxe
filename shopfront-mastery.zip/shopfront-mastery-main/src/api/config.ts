// Centralized API configuration
// Replace BASE_URL with your Express.js backend URL when ready
export const API_BASE_URL = '/api';

export const API_ENDPOINTS = {
  // Products
  PRODUCTS: `${API_BASE_URL}/products`,
  PRODUCT_BY_ID: (id: string) => `${API_BASE_URL}/products/${id}`,
  CATEGORIES: `${API_BASE_URL}/categories`,
  
  // Auth
  LOGIN: `${API_BASE_URL}/auth/login`,
  REGISTER: `${API_BASE_URL}/auth/register`,
  
  // User
  USER_PROFILE: `${API_BASE_URL}/user/profile`,
  
  // Cart
  CART: `${API_BASE_URL}/cart`,
  CART_ADD: `${API_BASE_URL}/cart/add`,
  CART_REMOVE: (id: string) => `${API_BASE_URL}/cart/remove/${id}`,
  
  // Orders
  ORDERS_CREATE: `${API_BASE_URL}/orders/create`,
  ORDERS_USER: `${API_BASE_URL}/orders/user`,
  
  // Admin
  ADMIN_PRODUCTS: `${API_BASE_URL}/admin/products`,
  ADMIN_PRODUCT_BY_ID: (id: string) => `${API_BASE_URL}/admin/products/${id}`,
  ADMIN_ORDERS: `${API_BASE_URL}/admin/orders`,
  ADMIN_DASHBOARD: `${API_BASE_URL}/admin/dashboard`,
};
