// Authentication API Layer
// Replace mock implementations with actual API calls when backend is ready

import { User, AuthResponse } from '@/types';
import { mockUser, mockAdminUser } from './mockData';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Token storage keys
const TOKEN_KEY = 'auth_token';
const USER_KEY = 'auth_user';

/**
 * Login user
 * Backend endpoint: POST /api/auth/login
 */
export const login = async (
  email: string,
  password: string
): Promise<AuthResponse> => {
  await delay(500); // Simulate network delay

  // Mock validation - replace with actual API call
  if (!email || !password) {
    throw new Error('Email and password are required');
  }

  // Demo credentials
  if (email === 'admin@example.com' && password === 'admin123') {
    const token = 'mock_admin_token_' + Date.now();
    return { user: mockAdminUser, token };
  }

  if (email === 'user@example.com' && password === 'user123') {
    const token = 'mock_user_token_' + Date.now();
    return { user: mockUser, token };
  }

  // For demo purposes, accept any valid-looking email/password
  if (password.length >= 6) {
    const token = 'mock_token_' + Date.now();
    const user: User = {
      id: Date.now().toString(),
      email,
      name: email.split('@')[0],
      role: 'user',
      createdAt: new Date().toISOString(),
    };
    return { user, token };
  }

  throw new Error('Invalid email or password');
};

/**
 * Register new user
 * Backend endpoint: POST /api/auth/register
 */
export const register = async (
  name: string,
  email: string,
  password: string
): Promise<AuthResponse> => {
  await delay(600);

  // Mock validation
  if (!name || !email || !password) {
    throw new Error('All fields are required');
  }

  if (password.length < 6) {
    throw new Error('Password must be at least 6 characters');
  }

  // Mock user creation
  const token = 'mock_token_' + Date.now();
  const user: User = {
    id: Date.now().toString(),
    email,
    name,
    role: 'user',
    createdAt: new Date().toISOString(),
  };

  return { user, token };
};

/**
 * Get current user profile
 * Backend endpoint: GET /api/user/profile
 */
export const getProfile = async (token: string): Promise<User> => {
  await delay(200);

  if (!token) {
    throw new Error('Authentication required');
  }

  // In real implementation, decode token or fetch from API
  const storedUser = localStorage.getItem(USER_KEY);
  if (storedUser) {
    return JSON.parse(storedUser);
  }

  return mockUser;
};

/**
 * Update user profile
 * Backend endpoint: PUT /api/user/profile
 */
export const updateProfile = async (
  token: string,
  updates: Partial<User>
): Promise<User> => {
  await delay(400);

  if (!token) {
    throw new Error('Authentication required');
  }

  const storedUser = localStorage.getItem(USER_KEY);
  if (storedUser) {
    const user = { ...JSON.parse(storedUser), ...updates };
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    return user;
  }

  return { ...mockUser, ...updates };
};

/**
 * Logout user
 * Backend endpoint: POST /api/auth/logout
 */
export const logout = async (): Promise<void> => {
  await delay(100);
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
};

// Helper functions for token management
export const saveAuthData = (token: string, user: User): void => {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};

export const getStoredToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};

export const getStoredUser = (): User | null => {
  const user = localStorage.getItem(USER_KEY);
  return user ? JSON.parse(user) : null;
};

export const clearAuthData = (): void => {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
};
