// Order API Layer
// Replace mock implementations with actual API calls when backend is ready

import { Order, CartItem, Address } from '@/types';
import { mockOrders } from './mockData';
import { clearCart } from './cartApi';

const ORDERS_KEY = 'user_orders';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Helper to get orders from localStorage
const getStoredOrders = (): Order[] => {
  const orders = localStorage.getItem(ORDERS_KEY);
  return orders ? JSON.parse(orders) : mockOrders;
};

// Helper to save orders to localStorage
const saveOrders = (orders: Order[]): void => {
  localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
};

/**
 * Get user orders
 * Backend endpoint: GET /api/orders/user
 */
export const getUserOrders = async (): Promise<Order[]> => {
  await delay(300);
  return getStoredOrders();
};

/**
 * Get order by ID
 * Backend endpoint: GET /api/orders/:id
 */
export const getOrderById = async (orderId: string): Promise<Order | null> => {
  await delay(200);
  const orders = getStoredOrders();
  return orders.find(o => o.id === orderId) || null;
};

/**
 * Create new order
 * Backend endpoint: POST /api/orders/create
 */
export const createOrder = async (
  items: CartItem[],
  shippingAddress: Address,
  userId: string
): Promise<Order> => {
  await delay(500);

  const orderId = `ORD-${Date.now().toString(36).toUpperCase()}`;
  const now = new Date().toISOString();

  const order: Order = {
    id: orderId,
    userId,
    items: items.map(item => ({
      productId: item.productId,
      quantity: item.quantity,
      price: item.product.price,
      product: item.product,
    })),
    total: items.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
    status: 'pending',
    shippingAddress,
    createdAt: now,
    updatedAt: now,
  };

  const orders = getStoredOrders();
  orders.unshift(order);
  saveOrders(orders);

  // Clear cart after successful order
  await clearCart();

  return order;
};

/**
 * Cancel order
 * Backend endpoint: PUT /api/orders/:id/cancel
 */
export const cancelOrder = async (orderId: string): Promise<Order> => {
  await delay(300);

  const orders = getStoredOrders();
  const index = orders.findIndex(o => o.id === orderId);

  if (index === -1) {
    throw new Error('Order not found');
  }

  if (!['pending', 'processing'].includes(orders[index].status)) {
    throw new Error('Cannot cancel order in current status');
  }

  orders[index].status = 'cancelled';
  orders[index].updatedAt = new Date().toISOString();
  saveOrders(orders);

  return orders[index];
};

// Admin functions

/**
 * Get all orders (admin)
 * Backend endpoint: GET /api/admin/orders
 */
export const getAllOrders = async (): Promise<Order[]> => {
  await delay(300);
  return getStoredOrders();
};

/**
 * Update order status (admin)
 * Backend endpoint: PUT /api/admin/orders/:id/status
 */
export const updateOrderStatus = async (
  orderId: string,
  status: Order['status']
): Promise<Order> => {
  await delay(300);

  const orders = getStoredOrders();
  const index = orders.findIndex(o => o.id === orderId);

  if (index === -1) {
    throw new Error('Order not found');
  }

  orders[index].status = status;
  orders[index].updatedAt = new Date().toISOString();
  saveOrders(orders);

  return orders[index];
};
