// Product API Layer
// Replace mock implementations with actual API calls when backend is ready

import { Product, PaginatedResponse, ProductFilters } from '@/types';
import { mockProducts, mockCategories } from './mockData';

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Fetch all products with optional filters
 * Backend endpoint: GET /api/products
 */
export const getProducts = async (
  filters?: ProductFilters,
  page = 1,
  limit = 12
): Promise<PaginatedResponse<Product>> => {
  await delay(300); // Simulate network delay

  let filtered = [...mockProducts];

  // Apply filters
  if (filters?.category) {
    filtered = filtered.filter(p => p.category === filters.category);
  }

  if (filters?.minPrice !== undefined) {
    filtered = filtered.filter(p => p.price >= filters.minPrice!);
  }

  if (filters?.maxPrice !== undefined) {
    filtered = filtered.filter(p => p.price <= filters.maxPrice!);
  }

  if (filters?.rating !== undefined) {
    filtered = filtered.filter(p => p.rating >= filters.rating!);
  }

  if (filters?.search) {
    const searchLower = filters.search.toLowerCase();
    filtered = filtered.filter(
      p =>
        p.name.toLowerCase().includes(searchLower) ||
        p.description.toLowerCase().includes(searchLower)
    );
  }

  // Apply sorting
  if (filters?.sortBy) {
    switch (filters.sortBy) {
      case 'price-asc':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        // In real app, sort by createdAt
        break;
    }
  }

  // Paginate
  const total = filtered.length;
  const totalPages = Math.ceil(total / limit);
  const start = (page - 1) * limit;
  const data = filtered.slice(start, start + limit);

  return {
    data,
    total,
    page,
    limit,
    totalPages,
  };
};

/**
 * Fetch a single product by ID
 * Backend endpoint: GET /api/products/:id
 */
export const getProductById = async (id: string): Promise<Product | null> => {
  await delay(200);

  const product = mockProducts.find(p => p.id === id);
  return product || null;
};

/**
 * Fetch featured products
 * Backend endpoint: GET /api/products?featured=true
 */
export const getFeaturedProducts = async (): Promise<Product[]> => {
  await delay(200);

  return mockProducts.filter(p => p.featured);
};

/**
 * Fetch all categories
 * Backend endpoint: GET /api/categories
 */
export const getCategories = async () => {
  await delay(150);

  return mockCategories;
};

/**
 * Fetch products by category
 * Backend endpoint: GET /api/categories/:category/products
 */
export const getProductsByCategory = async (
  category: string,
  page = 1,
  limit = 12
): Promise<PaginatedResponse<Product>> => {
  return getProducts({ category }, page, limit);
};

/**
 * Search products
 * Backend endpoint: GET /api/products/search?q=query
 */
export const searchProducts = async (query: string): Promise<Product[]> => {
  await delay(200);

  const searchLower = query.toLowerCase();
  return mockProducts.filter(
    p =>
      p.name.toLowerCase().includes(searchLower) ||
      p.description.toLowerCase().includes(searchLower) ||
      p.category.toLowerCase().includes(searchLower)
  );
};
